Enviornment Requirement 

OS : Windows 7 32 bit

Database : Oracle 10G Express Edition

--------------------------------------------------------

1. Install Oracle 10G Express Edition and Set Password as Manager During Installation.
2. Go To Database > Import Sql Script From DB.Sql
3. Install Visual Basic 6.0 
4. Register All Ocx Files Provided in OCX Folder .(All 5 are important)
   -> Run On Cmd	
		 Regsvr32 "Path_of_Ocx.Ocx"
5. Enjoy 