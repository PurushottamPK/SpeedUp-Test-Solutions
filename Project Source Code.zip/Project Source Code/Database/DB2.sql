conn sts/sts
/
Delete from  EXP
/
Delete from  INCM
/
Delete from  CLIENT_PMT
/
Delete from  CLNT_ORDR_CHLN
/
Delete from  CLIENT
/
Delete from  PKG_RENEW
/
Delete from STURANK
/
Delete from  STUD_PREV_REC
/
Delete from  RPTSTUDENTS
/
Delete from  QTESTBANK
/
Delete from  mcqtest
/
Delete from  SECQUES
/
Delete from  QPAPRDASH
/
Delete from  FULLMOCKTEST
/
Delete from  SUBWISETEST
/
Delete from  TOPICWISETEST
/
Delete from  QPAPERFINAL
/
Delete from  quesMS
/
Delete from  pkg
/
Delete from  schdl
/
Delete from  topic
/
Delete from  sub 
/
Delete from  course
/
Delete from  Q_TYP
/
commit
/
exit
/
exit
/